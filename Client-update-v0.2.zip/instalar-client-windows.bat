@echo off
setlocal
set "APP_DIR=%~dp0"
set "SHORTCUT=%USERPROFILE%\Desktop\Orcamentos RGA Client.lnk"
set "ICON=%APP_DIR%assets\dev.ico"

set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

if not exist "%EDGE%" (
  echo Microsoft Edge nao encontrado.
  echo Use o arquivo abrir-app.bat ou instale o Microsoft Edge.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "$url=(New-Object System.Uri((Resolve-Path '%APP_DIR%index.html').Path)).AbsoluteUri; $w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut('%SHORTCUT%'); $s.TargetPath='%EDGE%'; $s.Arguments='--app=""'+$url+'"" --user-data-dir=""%APP_DIR%client-profile""'; $s.WorkingDirectory='%APP_DIR%'; $s.IconLocation='%ICON%'; $s.Description='Client de orcamentos RGA'; $s.Save()"

echo.
echo Client instalado na Area de Trabalho.
echo Procure pelo icone "Orcamentos RGA Client".
echo.
echo Abrindo o client agora...
call "%APP_DIR%abrir-client-windows.bat"
pause
