# App de Orçamentos para Marmoraria

Aplicativo local para montar orçamentos de materiais, serviços e gerar a visualização pronta para imprimir em PDF.

## Como abrir

1. Dê dois cliques em `abrir-app.bat`.
2. O navegador abre o arquivo `index.html`.
3. Para gerar PDF, clique em `Gerar Orçamento PDF` e escolha `Salvar como PDF`.

Os dados ficam salvos no navegador automaticamente enquanto você trabalha.

## Instalar como app no Windows

Dê dois cliques em `instalar-app-windows.bat`. Ele cria um ícone chamado `Orcamentos RGA` na Área de Trabalho.

## Abrir como client sem cara de navegador

Dê dois cliques em `instalar-client-windows.bat`. Ele cria um ícone chamado `Orcamentos RGA Client` que abre em uma janela própria, sem barra de endereço.

Se quiser abrir direto sem reinstalar, use `abrir-client-windows.bat`.

## Usar no celular

Dê dois cliques em `abrir-no-celular.bat`. Ele mostra um link `http://...:5173` para abrir no celular, desde que o PC e o celular estejam no mesmo Wi-Fi.
