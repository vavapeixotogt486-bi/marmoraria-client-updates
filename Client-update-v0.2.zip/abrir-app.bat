@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$edge=$env:ProgramFiles(x86)+'\Microsoft\Edge\Application\msedge.exe'; if(!(Test-Path $edge)){ $edge=$env:ProgramFiles+'\Microsoft\Edge\Application\msedge.exe' }; if(!(Test-Path $edge)){ Start-Process '%~dp0index.html'; exit }; $url=(New-Object System.Uri((Resolve-Path '%~dp0index.html').Path)).AbsoluteUri; Start-Process $edge -ArgumentList @('--app='+$url, '--user-data-dir=%~dp0client-profile')"
