@echo off
setlocal
set "APP_DIR=%~dp0"

set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

if not exist "%EDGE%" (
  echo Microsoft Edge nao encontrado.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "$url=(New-Object System.Uri((Resolve-Path '%APP_DIR%index.html').Path)).AbsoluteUri; Start-Process '%EDGE%' -ArgumentList @('--app='+$url, '--user-data-dir=%APP_DIR%client-profile')"
